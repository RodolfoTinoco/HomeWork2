package com.example.rodolfo.homework21;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static android.R.id.button1;

public class Exercise extends AppCompatActivity {

    private Button btm1;
    private Button btm2;
    private Button btm3;
    private Button btm4;
    private EditText password;
    private Button btmCheck;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_exercise);

        setupUIViews();

        btm1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                password.setText(password.getText().toString()+"1");
            }
        });

        btm2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                password.setText(password.getText().toString()+"2");
            }
        });

        btm3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                password.setText(password.getText().toString()+"3");
            }
        });

        btm4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                password.setText(password.getText().toString()+"4");
            }
        });


        btmCheck.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view){
                checkPassword(password.getText().toString());
            }
        });

    }

    private void checkPassword(String password){
        if (password.equals("1234")){
            Intent intent = new Intent(Exercise.this, UnlockedScreen.class);
            startActivity(intent);
        }else{
            Toast.makeText(getApplicationContext(),"Incorrect", Toast.LENGTH_SHORT).show();
        }
    }


    private void setupUIViews(){
        btm1 = (Button)findViewById(R.id.btm1);
        btm2 = (Button)findViewById(R.id.btm2);
        btm3 = (Button)findViewById(R.id.btm3);
        btm4 = (Button)findViewById(R.id.btm4);
        password = (EditText)findViewById(R.id.passwordField);
        btmCheck = (Button)findViewById(R.id.btmcheck);
    }

}
